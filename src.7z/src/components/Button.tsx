import React from 'react';

interface ButtonProps {
  onClick: () => void;
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'accent' | 'function';
  className?: string;
  size?: 'normal' | 'wide';
}

export function Button({ 
  onClick, 
  children, 
  variant = 'primary', 
  className = '',
  size = 'normal'
}: ButtonProps) {
  const baseStyles = 'rounded-lg font-medium text-lg transition-all duration-150 active:scale-95 shadow-lg';
  const sizeStyles = {
    normal: 'h-14',
    wide: 'h-14 col-span-2'
  };
  const variantStyles = {
    primary: 'bg-gray-700 hover:bg-gray-600 text-white shadow-gray-800/20',
    secondary: 'bg-gray-600 hover:bg-gray-500 text-white shadow-gray-800/20',
    accent: 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white shadow-blue-700/30',
    function: 'bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-400 text-white shadow-purple-700/30'
  };

  return (
    <button
      onClick={onClick}
      className={`${baseStyles} ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
    >
      {children}
    </button>
  );
}