export function formatTime(date: Date): string {
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
}

export function parseTime(timeStr: string, period: 'AM' | 'PM'): Date {
  const [hours, minutes] = timeStr.split(':').map(Number);
  const date = new Date();
  
  let adjustedHours = hours;
  if (period === 'PM' && hours !== 12) {
    adjustedHours += 12;
  } else if (period === 'AM' && hours === 12) {
    adjustedHours = 0;
  }
  
  date.setHours(adjustedHours, minutes, 0, 0);
  return date;
}

export function getTimeUntil(targetDate: Date): number {
  const now = new Date();
  let diff = targetDate.getTime() - now.getTime();
  
  // If the time has passed today, set it for tomorrow
  if (diff < 0) {
    targetDate.setDate(targetDate.getDate() + 1);
    diff = targetDate.getTime() - now.getTime();
  }
  
  return Math.floor(diff / 1000);
}