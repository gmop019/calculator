export const operations = {
  // Basic Operations
  add: (a: number, b: number) => a + b,
  subtract: (a: number, b: number) => a - b,
  multiply: (a: number, b: number) => a * b,
  divide: (a: number, b: number) => b !== 0 ? a / b : 'Error',
  
  // Power and Roots
  power: (a: number, b: number) => Math.pow(a, b),
  sqrt: (a: number) => a >= 0 ? Math.sqrt(a) : 'Error',
  cbrt: (a: number) => Math.cbrt(a),
  
  // Trigonometric Functions (with automatic degree to radian conversion)
  sin: (a: number) => Math.sin(a * Math.PI / 180),
  cos: (a: number) => Math.cos(a * Math.PI / 180),
  tan: (a: number) => Math.tan(a * Math.PI / 180),
  
  // Inverse Trigonometric Functions
  asin: (a: number) => (Math.asin(a) * 180 / Math.PI),
  acos: (a: number) => (Math.acos(a) * 180 / Math.PI),
  atan: (a: number) => (Math.atan(a) * 180 / Math.PI),
  
  // Logarithmic Functions
  log: (a: number) => a > 0 ? Math.log10(a) : 'Error',
  ln: (a: number) => a > 0 ? Math.log(a) : 'Error',
  
  // Additional Functions
  exp: (a: number) => Math.exp(a),
  abs: (a: number) => Math.abs(a),
  factorial: (a: number) => {
    if (a < 0 || !Number.isInteger(a)) return 'Error';
    if (a === 0) return 1;
    let result = 1;
    for (let i = 2; i <= a; i++) result *= i;
    return result;
  },
  percent: (a: number) => a / 100,
};

export type Operation = keyof typeof operations;

export const operationLabels: Record<Operation, string> = {
  add: '+',
  subtract: '−',
  multiply: '×',
  divide: '÷',
  power: 'xʸ',
  sqrt: '√',
  cbrt: '∛',
  sin: 'sin',
  cos: 'cos',
  tan: 'tan',
  asin: 'sin⁻¹',
  acos: 'cos⁻¹',
  atan: 'tan⁻¹',
  log: 'log',
  ln: 'ln',
  exp: 'eˣ',
  abs: '|x|',
  factorial: 'x!',
  percent: '%'
};