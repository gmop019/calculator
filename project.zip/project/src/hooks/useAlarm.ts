import { useState, useEffect, useCallback } from 'react';
import { formatTime } from '../utils/timeUtils';

export function useAlarm() {
  const [targetTime, setTargetTime] = useState<Date | null>(null);
  const [remainingTime, setRemainingTime] = useState<number | null>(null);

  const playAlarmSound = useCallback(() => {
    const audio = new Audio('https://actions.google.com/sounds/v1/alarms/alarm_clock.ogg');
    audio.play().catch(console.error);
  }, []);

  const setAlarm = useCallback((seconds: number) => {
    const target = new Date();
    target.setSeconds(target.getSeconds() + seconds);
    setTargetTime(target);
  }, []);

  const cancelAlarm = useCallback(() => {
    setTargetTime(null);
    setRemainingTime(null);
  }, []);

  useEffect(() => {
    if (!targetTime) return;

    const interval = setInterval(() => {
      const now = new Date();
      const diff = Math.floor((targetTime.getTime() - now.getTime()) / 1000);

      if (diff <= 0) {
        playAlarmSound();
        cancelAlarm();
      } else {
        setRemainingTime(diff);
      }
    }, 1000);

    // Initial calculation
    const initialDiff = Math.floor((targetTime.getTime() - new Date().getTime()) / 1000);
    setRemainingTime(initialDiff);

    return () => clearInterval(interval);
  }, [targetTime, cancelAlarm, playAlarmSound]);

  return {
    remainingTime,
    setAlarm,
    cancelAlarm,
    alarmTime: targetTime ? formatTime(targetTime) : null
  };
}