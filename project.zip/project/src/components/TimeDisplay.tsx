import React, { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';
import { formatTime } from '../utils/timeUtils';

export function TimeDisplay() {
  const [currentTime, setCurrentTime] = useState(formatTime(new Date()));

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(formatTime(new Date()));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-center space-x-2 bg-gradient-to-r from-gray-700/30 to-gray-600/30 rounded-lg px-3 py-1.5 border border-gray-600/20">
      <Clock size={14} className="text-gray-400" />
      <span className="text-gray-300 font-mono text-sm font-medium tracking-wide">
        {currentTime}
      </span>
    </div>
  );
}