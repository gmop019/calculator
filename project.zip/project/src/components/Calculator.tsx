import React, { useState } from 'react';
import { Operation, operations, operationLabels } from '../utils/calculatorOperations';
import { Display } from './Display';
import { Button } from './Button';
import { AlarmModal } from './AlarmModal';
import { useAlarm } from '../hooks/useAlarm';

export function Calculator() {
  const [display, setDisplay] = useState('0');
  const [expression, setExpression] = useState('');
  const [firstOperand, setFirstOperand] = useState<number | null>(null);
  const [operation, setOperation] = useState<Operation | null>(null);
  const [newNumber, setNewNumber] = useState(true);
  const [memory, setMemory] = useState<number | null>(null);
  const [angle, setAngle] = useState<'DEG' | 'RAD'>('DEG');
  const [shift, setShift] = useState(false);
  const [isAlarmModalOpen, setIsAlarmModalOpen] = useState(false);
  const { remainingTime, setAlarm, cancelAlarm } = useAlarm();

  const handleNumber = (num: string) => {
    if (newNumber) {
      setDisplay(num);
      setNewNumber(false);
    } else {
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const handleOperation = (op: Operation) => {
    const current = parseFloat(display);
    if (firstOperand === null) {
      setFirstOperand(current);
      setOperation(op);
      setExpression(`${current} ${operationLabels[op]}`);
      setNewNumber(true);
    } else if (operation) {
      const result = operations[operation](firstOperand, current);
      setFirstOperand(typeof result === 'number' ? result : null);
      setDisplay(result.toString());
      setOperation(op);
      setExpression(`${result} ${operationLabels[op]}`);
      setNewNumber(true);
    }
  };

  const handleEquals = () => {
    if (firstOperand !== null && operation) {
      const current = parseFloat(display);
      const result = operations[operation](firstOperand, current);
      setDisplay(result.toString());
      setExpression(`${firstOperand} ${operationLabels[operation]} ${current} =`);
      setFirstOperand(null);
      setOperation(null);
      setNewNumber(true);
    }
  };

  const handleScientific = (op: Operation) => {
    const current = parseFloat(display);
    const result = operations[op](current);
    setDisplay(result.toString());
    setExpression(`${operationLabels[op]}(${current})`);
    setNewNumber(true);
  };

  const handleMemory = (action: 'M+' | 'M-' | 'MR' | 'MC') => {
    const current = parseFloat(display);
    switch (action) {
      case 'M+':
        setMemory((memory || 0) + current);
        break;
      case 'M-':
        setMemory((memory || 0) - current);
        break;
      case 'MR':
        if (memory !== null) {
          setDisplay(memory.toString());
          setNewNumber(true);
        }
        break;
      case 'MC':
        setMemory(null);
        break;
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setExpression('');
    setFirstOperand(null);
    setOperation(null);
    setNewNumber(true);
  };

  const handleToggleAngle = () => {
    setAngle(angle === 'DEG' ? 'RAD' : 'DEG');
  };

  const handleBackspace = () => {
    if (!newNumber && display !== '0') {
      setDisplay(display.length === 1 ? '0' : display.slice(0, -1));
    }
  };

  const handleToggleSign = () => {
    setDisplay(display.startsWith('-') ? display.slice(1) : '-' + display);
  };

  return (
    <>
      <div className="w-full max-w-md bg-gray-900 rounded-lg shadow-2xl overflow-hidden border border-gray-800">
        <Display 
          value={display} 
          expression={expression} 
          memory={memory?.toString() || ''} 
          angle={angle}
          remainingTime={remainingTime}
          onCancelAlarm={cancelAlarm}
        />
        
        <div className="p-4 grid grid-cols-4 gap-2">
          {/* Memory and Clear Row */}
          <Button variant="function" onClick={() => handleMemory('MC')}>MC</Button>
          <Button variant="function" onClick={() => handleMemory('MR')}>MR</Button>
          <Button variant="function" onClick={() => handleMemory('M+')}>M+</Button>
          <Button variant="function" onClick={() => handleMemory('M-')}>M−</Button>

          {/* Function Row */}
          <Button variant="secondary" onClick={handleClear}>C</Button>
          <Button variant="secondary" onClick={handleBackspace}>⌫</Button>
          <Button variant="secondary" onClick={handleToggleSign}>±</Button>
          <Button variant="accent" onClick={() => handleOperation('divide')}>÷</Button>

          {/* Scientific Functions */}
          <Button variant="secondary" onClick={() => handleScientific(shift ? 'asin' : 'sin')}>
            {shift ? 'sin⁻¹' : 'sin'}
          </Button>
          <Button variant="secondary" onClick={() => handleScientific(shift ? 'acos' : 'cos')}>
            {shift ? 'cos⁻¹' : 'cos'}
          </Button>
          <Button variant="secondary" onClick={() => handleScientific(shift ? 'atan' : 'tan')}>
            {shift ? 'tan⁻¹' : 'tan'}
          </Button>
          <Button variant="accent" onClick={() => handleOperation('multiply')}>×</Button>

          {/* Numbers and Operations */}
          <Button onClick={() => handleNumber('7')}>7</Button>
          <Button onClick={() => handleNumber('8')}>8</Button>
          <Button onClick={() => handleNumber('9')}>9</Button>
          <Button variant="accent" onClick={() => handleOperation('subtract')}>−</Button>

          <Button onClick={() => handleNumber('4')}>4</Button>
          <Button onClick={() => handleNumber('5')}>5</Button>
          <Button onClick={() => handleNumber('6')}>6</Button>
          <Button variant="accent" onClick={() => handleOperation('add')}>+</Button>

          <Button onClick={() => handleNumber('1')}>1</Button>
          <Button onClick={() => handleNumber('2')}>2</Button>
          <Button onClick={() => handleNumber('3')}>3</Button>
          <Button variant="accent" onClick={() => handleOperation('power')}>xʸ</Button>

          {/* Bottom Row */}
          <Button onClick={() => handleNumber('0')}>0</Button>
          <Button onClick={() => handleNumber('.')}>.</Button>
          <Button variant="secondary" onClick={() => setShift(!shift)}>
            {shift ? '2ⁿᵈ' : '2ⁿᵈ'}
          </Button>
          <Button variant="accent" onClick={handleEquals}>=</Button>

          {/* Additional Functions */}
          <Button variant="secondary" onClick={() => handleScientific('sqrt')}>√</Button>
          <Button variant="secondary" onClick={() => handleScientific('cbrt')}>∛</Button>
          <Button variant="secondary" onClick={() => handleScientific('exp')}>eˣ</Button>
          <Button variant="secondary" onClick={() => setIsAlarmModalOpen(true)}>
            Set Alarm
          </Button>
        </div>
      </div>

      <AlarmModal
        isOpen={isAlarmModalOpen}
        onClose={() => setIsAlarmModalOpen(false)}
        onSetAlarm={setAlarm}
      />
    </>
  );
}