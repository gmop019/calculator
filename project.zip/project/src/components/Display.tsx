import React from 'react';
import { AlarmIndicator } from './AlarmIndicator';
import { TimeDisplay } from './TimeDisplay';

interface DisplayProps {
  value: string;
  expression: string;
  memory: string;
  angle: string;
  remainingTime: number | null;
  onCancelAlarm: () => void;
}

export function Display({ 
  value, 
  expression, 
  memory, 
  angle,
  remainingTime,
  onCancelAlarm
}: DisplayProps) {
  return (
    <div className="w-full bg-gradient-to-b from-gray-900 via-gray-850 to-gray-800 p-6 rounded-t-lg">
      <div className="flex justify-between items-center mb-3">
        <div className="flex items-center space-x-3">
          <TimeDisplay />
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 bg-gray-700/40 rounded-md text-xs font-medium text-gray-300">
              {angle}
            </span>
            {memory && (
              <span className="px-2 py-0.5 bg-purple-500/20 text-purple-300 rounded-md text-xs font-medium">
                M
              </span>
            )}
          </div>
        </div>
        <AlarmIndicator 
          remainingTime={remainingTime} 
          onCancelAlarm={onCancelAlarm}
        />
      </div>
      <div className="space-y-2">
        <div className="text-gray-400 text-right font-mono text-sm min-h-[1.5rem] overflow-hidden">
          {expression || '\u00A0'}
        </div>
        <div className="text-white text-right text-5xl font-mono font-light tracking-tight truncate">
          {value || '0'}
        </div>
      </div>
    </div>
  );
}