import React, { useState } from 'react';
import { X, Clock } from 'lucide-react';
import { parseTime, getTimeUntil } from '../utils/timeUtils';

interface AlarmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSetAlarm: (seconds: number) => void;
}

export function AlarmModal({ isOpen, onClose, onSetAlarm }: AlarmModalProps) {
  const [time, setTime] = useState('12:00');
  const [period, setPeriod] = useState<'AM' | 'PM'>('AM');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const targetDate = parseTime(time, period);
    const secondsUntil = getTimeUntil(targetDate);
    onSetAlarm(secondsUntil);
    onClose();
  };

  const now = new Date();
  const currentHours = now.getHours();
  const currentMinutes = now.getMinutes();
  const defaultTime = `${String(currentHours % 12 || 12).padStart(2, '0')}:${String(currentMinutes).padStart(2, '0')}`;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gradient-to-b from-gray-800 to-gray-900 rounded-2xl p-6 w-80 relative border border-gray-700 shadow-xl">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
        >
          <X size={20} />
        </button>
        
        <div className="flex items-center space-x-3 mb-6">
          <Clock className="text-blue-400" size={24} />
          <h2 className="text-white text-xl font-semibold">Set Alarm</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="time" className="block text-gray-300 text-sm font-medium mb-2">
              Select Time
            </label>
            <input
              type="time"
              id="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full bg-gray-700/50 text-white rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-lg"
              required
            />
          </div>
          
          <div>
            <label className="block text-gray-300 text-sm font-medium mb-2">
              Select Period
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setPeriod('AM')}
                className={`px-4 py-3 rounded-xl font-medium transition-all duration-200 ${
                  period === 'AM'
                    ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-lg shadow-blue-500/30'
                    : 'bg-gray-700/50 text-gray-300 hover:bg-gray-700'
                }`}
              >
                AM
              </button>
              <button
                type="button"
                onClick={() => setPeriod('PM')}
                className={`px-4 py-3 rounded-xl font-medium transition-all duration-200 ${
                  period === 'PM'
                    ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-lg shadow-blue-500/30'
                    : 'bg-gray-700/50 text-gray-300 hover:bg-gray-700'
                }`}
              >
                PM
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white rounded-xl py-3 font-medium transition-all duration-200 shadow-lg shadow-blue-500/30 mt-6"
          >
            Set Alarm
          </button>
        </form>
      </div>
    </div>
  );
}