import React from 'react';
import { Bell, Clock } from 'lucide-react';

interface AlarmIndicatorProps {
  remainingTime: number | null;
  onCancelAlarm: () => void;
}

export function AlarmIndicator({ remainingTime, onCancelAlarm }: AlarmIndicatorProps) {
  if (remainingTime === null) return null;

  const hours = Math.floor(remainingTime / 3600);
  const minutes = Math.floor((remainingTime % 3600) / 60);
  const seconds = remainingTime % 60;

  const timeString = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  return (
    <div className="flex items-center space-x-2 bg-gradient-to-r from-blue-500/20 to-blue-400/20 rounded-lg px-3 py-1.5 border border-blue-400/30">
      <Clock size={14} className="text-blue-300" />
      <span className="text-blue-200 font-mono text-sm font-medium tracking-wider">
        {timeString}
      </span>
      <button
        onClick={onCancelAlarm}
        className="text-blue-300 hover:text-blue-200 transition-colors focus:outline-none"
        title="Cancel alarm"
      >
        <Bell size={14} />
      </button>
    </div>
  );
}